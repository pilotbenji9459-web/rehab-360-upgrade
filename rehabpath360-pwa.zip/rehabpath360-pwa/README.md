# RehabPath360 PWA (prototype, synthetic data)

Files: index.html (the app), manifest.webmanifest, sw.js (offline cache), icons.

## Run it
PWAs need HTTPS (localhost also works).
- Quick test: `python3 -m http.server 8080` in this folder, open http://localhost:8080
- Host free: drag this folder onto Netlify Drop, or push to GitHub Pages / Cloudflare Pages / Vercel.

## Install
- Android Chrome: menu > Install app (or the in-app "Install app" button).
- iPhone Safari: Share > Add to Home Screen.
- Desktop Chrome/Edge: install icon in the address bar.

## Notes
- Works offline after the first visit (fonts fall back to system fonts offline until cached).
- Data is still in-memory and resets on reload. Real logins, a database and server-side audit logs are the next step before any real use.
- After editing files, bump `V` in sw.js (e.g. rp360-v2) so installed copies update.
